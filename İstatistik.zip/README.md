# Euroleague Basketball Statistical Analysis

This project performs comprehensive statistical analysis on Euroleague basketball data, including data preprocessing, descriptive statistics, correlation analysis, regression analysis, and ANOVA testing.

## Project Structure

- `euroleague_analysis.py`: Main analysis script
- `requirements.txt`: Required Python packages
- `Euroleague_data/`: Directory containing the dataset files

## Setup Instructions

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install required packages:
```bash
pip install -r requirements.txt
```

3. Run the analysis:
```bash
python euroleague_analysis.py
```

## Analysis Components

1. Data Preparation and Preprocessing
   - Data cleaning and merging
   - Handling missing values
   - Creating performance metrics

2. Descriptive Statistics and Visualization
   - Summary statistics
   - Trend analysis
   - Correlation analysis

3. Statistical Analysis
   - Correlation analysis
   - Linear regression
   - ANOVA testing
   - Outstanding player identification

## Data Files

The analysis uses the following data files from the Euroleague dataset:
- euroleague_players.csv
- euroleague_box_score.csv
- euroleague_points.csv
- euroleague_teams.csv
- euroleague_play_by_play.csv
- euroleague_header.csv
- euroleague_comparison.csv 